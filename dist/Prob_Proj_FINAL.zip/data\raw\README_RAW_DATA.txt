Large raw datasets (1.18 GB total across 6 external sources) are retained in the main project directory:
- data/raw/usaspending/usaspending.csv (226 MB)
- data/raw/creditcard.csv/creditcard.csv (144 MB)
- data/raw/PS_20174392719_1491204439457_log.csv (470 MB)
- data/raw/online+retail/Online Retail.xlsx (23 MB)
- WDI_CSV_2026_10_01/ (270 MB)

This distribution archive contains all complete application code, tests, trained models, reports, generated analytical figures, tables, curated panel data, and fixtures.
